﻿/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'az', {
	copy: 'Copyright &copy; $1. Bütün hüquqlar qorunur.',
	dlgTitle: 'CKEditor haqqında',
	help: 'Kömək üçün  $1 seçin',
	moreInfo: 'Lisenziya informasiyası üçün zəhmət olmasa saytımızı ziyarət edin:',
	title: 'CKEditor haqqında',
	userGuide: 'CKEditor İstifadəçilər üçün kitabça'
} );
